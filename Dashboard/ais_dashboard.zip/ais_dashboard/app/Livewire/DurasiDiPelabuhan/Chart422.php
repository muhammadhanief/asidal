<?php

namespace App\Livewire\DurasiDiPelabuhan;

use App\Models\meanMedianDurasiIndoPerNegaraKapal;
use Livewire\Component;

class Chart422 extends Component
{




    public function render()
    {
        return view('livewire.durasi-di-pelabuhan.chart422');
    }
}
