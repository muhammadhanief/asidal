<?php

namespace App\Livewire;

use Livewire\Component;

class PerairanIndonesia extends Component
{
    public function render()
    {
        return view('livewire.perairan-indonesia');
    }
}
