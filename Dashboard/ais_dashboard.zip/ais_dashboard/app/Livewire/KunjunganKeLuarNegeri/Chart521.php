<?php

namespace App\Livewire\KunjunganKeLuarNegeri;

use Livewire\Component;

class Chart521 extends Component
{
    public function render()
    {
        return view('livewire.kunjungan-ke-luar-negeri.chart521');
    }
}
