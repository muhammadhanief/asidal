<?php

namespace App\Livewire;

use Livewire\Component;

class DurasiDiPelabuhan extends Component
{
    public function render()
    {
        return view('livewire.durasi-di-pelabuhan');
    }
}
