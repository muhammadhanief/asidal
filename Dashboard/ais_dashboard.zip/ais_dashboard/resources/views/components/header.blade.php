<section class="max-w-sm sm:max-w-3xl">
    {{-- <h2 class="text-4xl font-extrabold dark:text-white">{{ $title }}</h2> --}}
    <p class="my-4 text-lg text-gray-500">
        {{ $slot }}
    </p>
</section>
