<!-- resources/views/components/card.blade.php -->

<div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8 {{ $class ?? '' }}">
    {{ $slot }}
</div>
