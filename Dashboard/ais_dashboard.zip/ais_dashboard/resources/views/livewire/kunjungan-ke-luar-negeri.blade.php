<div class="px-4 pt-8 sm:pt-2 ">
    <x-slot:title>Kunjungan ke Luar Negeri</x-slot:title>
    <div class="grid grid-cols-1 gap-4 pt-4 sm:grid-cols-1">
        <livewire:kunjungan-ke-luar-negeri.chart511 />
    </div>
    <div class="grid grid-cols-1 gap-4 pt-4 sm:grid-cols-2">
        {{-- <livewire:kunjungan-ke-luar-negeri.chart521 />
        <livewire:kunjungan-ke-luar-negeri.chart522 /> --}}
    </div>
</div>
