<!-- resources/views/components/card.blade.php -->

<div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8 <?php echo e($class ?? ''); ?>">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/components/card.blade.php ENDPATH**/ ?>