
<p class="my-10 text-sm text-center text-gray-500">
    &copy; <?php echo e(date('Y')); ?> <a href="#" class="hover:underline">Ladisa
        Busaina</a>
</p>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/components/footer.blade.php ENDPATH**/ ?>