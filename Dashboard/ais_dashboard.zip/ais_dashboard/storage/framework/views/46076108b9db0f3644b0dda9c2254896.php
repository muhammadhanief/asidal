<div class="px-4 pt-8 sm:pt-2 ">
     <?php $__env->slot('title', null, []); ?> Masuk-Keluar Pelabuhan Indonesia <?php $__env->endSlot(); ?>
    <div class="grid grid-cols-1 gap-4 pt-4 sm:grid-cols-2">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('masuk-keluar.chart311', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-295613385-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('masuk-keluar.chart312', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-295613385-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <div class="grid grid-cols-1 gap-4 pt-4 sm:grid-cols-2">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('masuk-keluar.chart321', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-295613385-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('masuk-keluar.chart322', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-295613385-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <div class="grid grid-cols-1 gap-4 pt-4">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('masuk-keluar.chart331', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-295613385-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <div class="grid grid-cols-1 gap-4 pt-4">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('masuk-keluar.chart341', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-295613385-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
</div>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/livewire/masuk-keluar.blade.php ENDPATH**/ ?>