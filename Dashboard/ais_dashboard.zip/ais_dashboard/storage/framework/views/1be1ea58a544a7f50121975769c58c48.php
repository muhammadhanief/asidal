<div class="px-4 pt-6">
     <?php $__env->slot('title', null, []); ?> Kapal Indonesia <?php $__env->endSlot(); ?>
    <div class="flex flex-row justify-between gap-4">
        
        
        <iframe src="<?php echo e(asset('components/visualization_movement_ln.html')); ?>" width="100%" height="600px"
            frameborder="0"></iframe>
    </div>
</div>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/livewire/kapal-indonesia.blade.php ENDPATH**/ ?>