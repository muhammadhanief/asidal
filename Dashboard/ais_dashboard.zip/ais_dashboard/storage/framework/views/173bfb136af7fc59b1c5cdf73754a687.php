<section class="max-w-sm sm:max-w-3xl">
    
    <p class="my-4 text-lg text-gray-500">
        <?php echo e($slot); ?>

    </p>
</section>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/components/header.blade.php ENDPATH**/ ?>