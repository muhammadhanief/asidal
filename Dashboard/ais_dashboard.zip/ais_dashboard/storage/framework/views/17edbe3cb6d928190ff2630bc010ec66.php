<div class="px-4 pt-8 sm:pt-2 ">
     <?php $__env->slot('title', null, []); ?> Durasi di Pelabuhan Indonesia <?php $__env->endSlot(); ?>
    <div class="grid grid-cols-1 gap-4 pt-4 sm:grid-cols-2">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('durasi-di-pelabuhan.chart411', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2294280647-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('durasi-di-pelabuhan.chart412', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2294280647-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <div class="grid grid-cols-1 gap-4 pt-4 sm:grid-cols-1">

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('durasi-di-pelabuhan.chart421', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2294280647-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <div class="grid grid-cols-1 gap-4 pt-4">
        
    </div>
</div>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/livewire/durasi-di-pelabuhan.blade.php ENDPATH**/ ?>