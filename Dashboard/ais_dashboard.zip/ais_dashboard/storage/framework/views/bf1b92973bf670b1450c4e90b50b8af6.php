<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
    
    <div class="flex flex-col mb-4">
        <div class="flex-shrink-0 pb-2">
            <span class="text-xl font-bold leading-none text-gray-900 ">Kapal <?php echo e($selectedMasukOrKeluar); ?> Pelabuhan
                Indonesia</span>
            
        </div>
        <div class="flex flex-wrap items-center justify-start flex-1 text-base font-bold text-green-500 gap-x-2 gap-y-2">
            
            <div>
                <button id="dropdownDelayButton" data-dropdown-toggle="dropdownDelay" data-dropdown-delay="500"
                    data-dropdown-trigger="hover"
                    class="inline-flex items-center px-4 py-2 text-xs font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                    type="button">Arah Kapal <svg class="w-2.5 h-2.5 ms-3" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 1 4 4 4-4" />
                    </svg>
                </button>
                <div id="dropdownDelay"
                    class="absolute right-0 z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                    <ul class="py-2 text-xs text-gray-700 dark:text-gray-200" aria-labelledby="dropdownDelayButton">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $masukOrKeluarOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $masukOrKeluarOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="#" wire:click.prevent="selectMasukOrKeluar('<?php echo e($masukOrKeluarOption); ?>')"
                                    class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"><?php echo e($masukOrKeluarOption); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
            </div>

            
            
            <div>
                <div class="relative dropdown-pendekatan">
                    <button id="dropdownSearchButtonPendekatan2" data-dropdown-toggle="dropdownSearchPendekatan2"
                        class="inline-flex items-center px-4 py-2 text-xs font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        type="button" aria-haspopup="true" aria-expanded="false"
                        onclick="toggleDropdown('dropdownSearchPendekatan2');">
                        Pendekatan
                        <svg class="w-2.5 h-2.5 ms-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                            fill="none" viewBox="0 0 10 6">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 1 4 4 4-4" />
                        </svg>
                    </button>
                    <div wire:ignore id="dropdownSearchPendekatan2"
                        class="absolute right-0 z-20 hidden mt-2 bg-white rounded-lg shadow w-60 dark:bg-gray-700">
                        <ul class="h-48 px-3 pb-3 overflow-y-auto text-xs text-gray-700 dark:text-gray-200">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pendekatanOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendekatanOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="flex items-center p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                                        <input wire:model.live="selectedPendekatan" id="pendekatan-<?php echo e($loop->index); ?>"
                                            type="checkbox" value="<?php echo e($pendekatanOption); ?>"
                                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                                        <label for="pendekatan-<?php echo e($loop->index); ?>"
                                            class="w-full text-xs font-medium text-gray-900 rounded ms-2 dark:text-gray-300"><?php echo e($pendekatanOption); ?></label>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                </div>
            </div>
            

            
            <div>
                <div class="relative dropdown-bulan">
                    <button id="dropdownSearchButtonBulan2" data-dropdown-toggle="dropdownSearchBulan2"
                        class="inline-flex items-center px-4 py-2 text-xs font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        type="button" aria-haspopup="true" aria-expanded="false"
                        onclick="toggleDropdown('dropdownSearchBulan2');">
                        Bulan
                        <svg class="w-2.5 h-2.5 ms-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                            fill="none" viewBox="0 0 10 6">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 1 4 4 4-4" />
                        </svg>
                    </button>
                    <div wire:ignore id="dropdownSearchBulan2"
                        class="absolute right-0 z-20 hidden mt-2 bg-white rounded-lg shadow w-60 dark:bg-gray-700">
                        <ul class="h-48 px-3 pb-3 overflow-y-auto text-xs text-gray-700 dark:text-gray-200">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bulanOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulanOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="flex items-center p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                                        <input wire:model.live='selectedBulan' id="bulan-<?php echo e($loop->index); ?>"
                                            type="checkbox" value="<?php echo e($bulanOption); ?>"
                                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                                        <label for="bulan-<?php echo e($loop->index); ?>2"
                                            class="w-full text-xs font-medium text-gray-900 rounded ms-2 dark:text-gray-300"><?php echo e($bulanOption); ?></label>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                </div>
            </div>
            

            
            <div>
                <div class="relative dropdown-pelabuhan">
                    <button id="dropdownSearchButtonPelabuhan2" data-dropdown-toggle="dropdownSearchPelabuhan2"
                        class="inline-flex items-center px-4 py-2 text-xs font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        type="button" aria-haspopup="true" aria-expanded="false"
                        onclick="toggleDropdown('dropdownSearchPelabuhan2');">
                        Pelabuhan
                        <svg class="w-2.5 h-2.5 ms-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                            fill="none" viewBox="0 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 1 4 4 4-4" />
                        </svg>
                    </button>
                    <div wire:ignore id="dropdownSearchPelabuhan2"
                        class="absolute right-0 z-50 hidden mt-2 bg-white rounded-lg shadow w-60 dark:bg-gray-700">
                        <ul class="h-48 px-3 pb-3 overflow-y-auto text-xs text-gray-700 dark:text-gray-200"
                            aria-labelledby="dropdownSearchButtonPelabuhan2">
                            <li>
                                <div
                                    class="flex items-center p-2 font-bold rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                                    <input wire:model.live='selectAllPelabuhan' id="selectAllPelabuhan2"
                                        type="checkbox"
                                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                                    <label for="selectAllPelabuhan2"
                                        class="w-full text-xs font-medium text-gray-900 rounded ms-2 dark:text-gray-300">Pilih
                                        semua</label>
                                </div>
                            </li>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pelabuhanOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelabuhanOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div
                                        class="flex items-center p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                                        <input wire:model.live='selectedPelabuhan'
                                            id="pelabuhan-<?php echo e($loop->index); ?>2" type="checkbox"
                                            value="<?php echo e($pelabuhanOption); ?>"
                                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                                        <label for="pelabuhan-<?php echo e($loop->index); ?>2"
                                            class="w-full text-xs font-medium text-gray-900 rounded ms-2 dark:text-gray-300"><?php echo e($pelabuhanOption); ?></label>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                </div>
            </div>
            

        </div>
    </div>
    <div wire:ignore>
        <div id="fig-chart312"></div>
    </div>
        <?php
        $__scriptKey = '2639260463-0';
        ob_start();
    ?>
        <script>
            // dropdown aja
            // document.addEventListener('DOMContentLoaded', function() {
            //     const dropdownButtons = document.querySelectorAll('[data-dropdown-toggle]');
            //     dropdownButtons.forEach(button => {
            //         button.addEventListener('click', function() {
            //             const dropdownId = button.getAttribute('data-dropdown-toggle');
            //             const dropdown = document.getElementById(dropdownId);

            //             // Tutup semua dropdown yang sedang terbuka
            //             const allDropdowns = document.querySelectorAll('[data-dropdown]');
            //             allDropdowns.forEach(dropdown => {
            //                 if (dropdown !== document.getElementById(dropdownId)) {
            //                     dropdown.classList.add('hidden');
            //                 }
            //             });

            //             // Toggle dropdown yang saat ini diklik
            //             dropdown.classList.toggle('hidden');
            //         });
            //     });
            // });

            // Declare chart2 in the global scope
            window.chart312 = null;

            chart312 = Highcharts.chart('fig-chart312', {
                chart: {
                    type: 'pie'
                },
                title: {
                    text: null
                },
                tooltip: {
                    enabled: false
                },
                plotOptions: {
                    pie: {
                        dataLabels: {
                            enabled: true,
                            style: {
                                fontSize: '15px' // Ukuran font label
                            },
                            format: '<b>{point.name}</b>: {point.y:.2f}%'
                        }
                    }
                },
                exporting: { // Menambahkan opsi export
                    enabled: true, // Aktifkan tombol export
                    buttons: {
                        contextButton: {
                            text: 'Unduh' // Text tombol export
                        }
                    }
                },
                series: [{
                    name: 'Persentase',
                    data: [
                        ['Chrome', 30.0],
                        ['Firefox', 25.0],
                        ['Edge', 15.0],
                        ['Safari', 10.0],
                        ['Others', 20.0]
                    ]
                }]
            });


            $wire.on('chart312Update', (dataPie) => {
                // Mengakses objek chart
                // console.log(dataPie)
                var chart = window.chart312;

                // Mengambil data baru dari Livewire
                var newData = dataPie[0].chartData;

                // Memperbarui data pada series pertama
                chart.series[0].setData(newData);

            });
        </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/livewire/masuk-keluar/chart312.blade.php ENDPATH**/ ?>