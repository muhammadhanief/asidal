<div class="px-4 pt-6">
     <?php $__env->slot('title', null, []); ?> Algoritma 1 <?php $__env->endSlot(); ?>
    <div class="flex flex-row justify-between gap-4">
        
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('page1.chart12', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2884872428-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
</div>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/livewire/menu-satu.blade.php ENDPATH**/ ?>