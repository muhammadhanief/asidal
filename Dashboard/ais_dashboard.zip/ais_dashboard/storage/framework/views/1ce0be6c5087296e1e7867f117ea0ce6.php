<div class="px-4 pt-6">
     <?php $__env->slot('title', null, []); ?> Perairan Indonesia <?php $__env->endSlot(); ?>
    <div class="flex flex-row justify-between gap-4">
        
        
        <!-- Contoh penggunaan di dalam Blade template -->
        <iframe src="<?php echo e(asset('components/visualization_movement_indo.html')); ?>" width="100%" height="600px"
            frameborder="0"></iframe>
    </div>
</div>
<?php /**PATH /Users/hanief/Documents/Politeknik Statistika STIS/Semester 7/Skripsi/L/Dashboard/ais_dashboard/resources/views/livewire/perairan-indonesia.blade.php ENDPATH**/ ?>