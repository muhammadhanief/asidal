<?php

namespace App\Livewire;

use Livewire\Component;

class KunjunganKeLuarNegeri extends Component
{
    public function render()
    {
        return view('livewire.kunjungan-ke-luar-negeri');
    }
}
