<?php

namespace App\Livewire\DurasiDiPelabuhan;

use Livewire\Component;

class Chart431 extends Component
{
    public function render()
    {
        return view('livewire.durasi-di-pelabuhan.chart431');
    }
}
