<div class="px-4 pt-8 sm:pt-2 ">
    <x-slot:title>Durasi di Pelabuhan Indonesia</x-slot:title>
    <div class="grid grid-cols-1 gap-4 pt-4 sm:grid-cols-2">
        <livewire:durasi-di-pelabuhan.chart411 />
        <livewire:durasi-di-pelabuhan.chart412 />
    </div>
    <div class="grid grid-cols-1 gap-4 pt-4 sm:grid-cols-1">

        <livewire:durasi-di-pelabuhan.chart421 />
    </div>
    <div class="grid grid-cols-1 gap-4 pt-4">
        {{-- <livewire:durasi-di-pelabuhan.chart422 />
        <livewire:durasi-di-pelabuhan.chart431 /> --}}
    </div>
</div>
